export const COLORS = {
  primary: "#66b3ff",
  secondary: "#000",
};
