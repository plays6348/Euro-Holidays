
export const transitionAll = "transform transition-all duration-200";