export const banner1 =
  "http://urgentvisa.co.uk/wp-content/uploads/2025/05/Artboard-1.png";

export const banner2 =
  "http://urgentvisa.co.uk/wp-content/uploads/2025/05/Artboard-1.png";

export const banner3 =
  "http://urgentvisa.co.uk/wp-content/uploads/2025/05/Artboard-1.png";

