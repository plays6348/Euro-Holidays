export const appName = "Euro Holidays";
export const number = "02080048744";
