export const appName = 'Fast Holidays';
