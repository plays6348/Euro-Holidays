module.exports = {
  resolve: {
    fallback: {
      fs: false,
    },
  },
};