import React from 'react';
import FilterSidebar from './components/FilterSidebar';

const destinations = () => {
  return (
    <div>
      {/* Other page content */}
      <FilterSidebar />
      {/* Other page content */}
    </div>
  );
};

export default destinations;